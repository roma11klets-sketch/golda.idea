# Как сделать APK

Приложение — это оболочка (Capacitor), которая показывает игру из папки `public`. Мультиплеер и ИИ идут через ваш сервер на Render, поэтому его нужно сначала запустить (см. главный README).

## Вариант 1. Без компьютера: GitHub собирает APK сам
1. В репозитории откройте **Settings -> Secrets and variables -> Actions -> Variables** и создайте переменную `GAME_SERVER_URL` со значением адреса игры на Render (например `https://island-game.onrender.com`, без слэша в конце).
2. Откройте вкладку **Actions -> Build Android APK -> Run workflow**.
3. Через 5-10 минут скачайте файл `island-game-apk` (внутри `app-debug.apk`) и установите на телефон. Нужно разрешить установку из неизвестных источников.

## Вариант 2. На компьютере
1. Установите Node.js 18+ и Android Studio.
2. В `public/config.js` впишите `window.GAME_SERVER = 'https://ВАШ-АДРЕС.onrender.com';`
3. В терминале: `cd mobile`, `npm install`, `npx cap add android`, `npx cap sync android`, `npx cap open android`.
4. В Android Studio: **Build -> Build APK(s)**.

## Для Google Play
Нужен подписанный релиз (Android App Bundle) и аккаунт разработчика. Это делается в Android Studio: **Build -> Generate Signed Bundle**. Смените `appId` в `mobile/capacitor.config.json` на свой уникальный.

## Замечания
- Игра подгружает 3D-библиотеку с cdnjs, поэтому нужен интернет. Для работы без сети положите `three.min.js` (r128) в `public/` и измените ссылку в `index.html`.
- Без `GAME_SERVER` приложение будет искать сервер по своему адресу и мультиплеер не заработает.
- Игру можно также просто установить как приложение из браузера (PWA): меню браузера -> «Добавить на главный экран».
