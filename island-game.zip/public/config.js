// Адрес сервера для приложения (APK). Для сайта оставьте пустым.
// Для APK укажите адрес с Render, например: 'https://island-game.onrender.com'
window.GAME_SERVER = '';
